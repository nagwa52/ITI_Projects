<?php
define("_driver_","mysql");
define("_host_","127.0.0.1");
define("_database_","ecommerce");
define("_username_","root");
define("_password_","");